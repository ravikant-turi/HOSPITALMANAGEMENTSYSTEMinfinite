package com.java.jsf.model;

public enum Specialization {
    HEART, SKIN, GENERAL, KIDNEY
}
